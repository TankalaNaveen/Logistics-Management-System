package com.alpha.MkLogistics.exception;

public class CargoNotFoundException extends RuntimeException{
	public CargoNotFoundException(String msg) {
		super(msg);
	}
}
