package com.alpha.MkLogistics.exception;

public class CargoAlreadyExistException extends RuntimeException{
	public CargoAlreadyExistException(String msg) {
		super(msg);
	}
}
