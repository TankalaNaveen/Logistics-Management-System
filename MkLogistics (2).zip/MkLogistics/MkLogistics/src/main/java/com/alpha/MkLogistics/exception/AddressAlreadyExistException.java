package com.alpha.MkLogistics.exception;

public class AddressAlreadyExistException extends RuntimeException{
	public AddressAlreadyExistException(String msg) {
		super(msg);
	}
}
