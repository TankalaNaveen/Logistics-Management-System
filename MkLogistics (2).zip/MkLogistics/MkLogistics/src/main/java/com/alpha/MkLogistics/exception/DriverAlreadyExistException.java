package com.alpha.MkLogistics.exception;

public class DriverAlreadyExistException extends RuntimeException{
	public DriverAlreadyExistException(String msg) {
		super(msg);
	}
}
