package com.alpha.MkLogistics.exception;

public class DriverNotFoundException extends RuntimeException{
	public DriverNotFoundException(String msg) {
		super(msg);
	}
}
