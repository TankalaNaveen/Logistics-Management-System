package com.alpha.MkLogistics.exception;

public class CarrierNotFoundException extends RuntimeException{
	public CarrierNotFoundException(String msg) {
		super(msg);
	}
}
