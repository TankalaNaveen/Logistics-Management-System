package com.alpha.MkLogistics.exception;

public class CarrierAlreadyExistException extends RuntimeException{
	public CarrierAlreadyExistException(String msg) {
		super(msg);
	}
}
